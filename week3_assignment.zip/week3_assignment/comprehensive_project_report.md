# Week 3 Assignment: Comprehensive Project Report

## Introduction
This report summarizes the work completed for Week 3 of the assignment, which involved two main parts: Sentiment Analysis using TextBlob and Stock Trend Prediction using LSTM with integrated sentiment and time series analysis. The objective was to understand sentiment distribution in text data and to predict stock price movements by combining sentiment features with historical stock prices.

---

## Part 1: Sentiment Analysis

### Objective
This report summarizes the sentiment analysis performed on a dataset of text reviews using TextBlob. The goal was to classify the sentiment of each review into positive, neutral, or negative categories and understand the overall sentiment distribution.

### Methodology
The `TextBlob` library was used to calculate the polarity of each review text. Based on the polarity score:
- Polarity > 0: Classified as 'positive'
- Polarity < 0: Classified as 'negative'
- Polarity = 0: Classified as 'neutral'

### Results
The sentiment analysis resulted in the following distribution:

| Sentiment Category | Number of Reviews | Percentage (%) |
| :----------------- | :---------------- | :------------- |
| Positive           | 11       | 55.00      |
| Negative           | 8       | 40.00      |
| Neutral            | 1       | 5.00      |

### Visualizations

#### Sentiment Distribution Bar Chart
![Sentiment Distribution Bar Chart](./part1/sentiment_distribution.png)

### Conclusion
The analysis provides insights into the general sentiment expressed in the reviews. The majority of reviews were classified as positive, indicating a generally positive perception of the product/service reviewed.

---

## Part 2: Stock Trend Prediction Using Sentiment and Time Series Analysis

### Objective
This report details the integration of sentiment analysis with financial time series modeling to predict stock price movements, building upon the sentiment analysis techniques from Part 1.

### Methodology
1.  **Dataset Preparation**: Historical AAPL stock prices were downloaded using `yfinance`. Synthetic news headlines were generated and assigned sentiment scores using `TextBlob`.
2.  **Sentiment Annotation**: News headlines were classified into positive (1), negative (-1), or neutral (0) sentiment. Daily average sentiment scores were calculated and merged with the stock price data.
3.  **Time Series Forecasting (LSTM)**: An LSTM (Long Short-Term Memory) neural network model was trained using a combination of historical stock prices (Open, High, Low, Close, Volume) and the derived sentiment features. The data was scaled using `MinMaxScaler` and prepared into sequences for LSTM input. The model was trained to predict the next day's closing price.
4.  **Evaluation**: The model's performance was evaluated by comparing actual vs. predicted stock prices on a test set.

### Results and Visualizations

#### AAPL Stock Price Prediction (LSTM with Sentiment)
![AAPL Stock Price Prediction](./part2/aapl_stock_prediction.png)

This chart compares the actual closing prices of AAPL stock against the prices predicted by the LSTM model, incorporating sentiment data. The model shows a general ability to follow the trend of the stock price.

#### AAPL Close Price and Daily Sentiment Over Time
![AAPL Close Price and Daily Sentiment](./part2/aapl_sentiment_vs_price.png)

This visualization displays the AAPL closing price alongside the aggregated daily sentiment score. It helps in visually identifying potential correlations or leading indicators between news sentiment and stock price movements. For instance, periods of consistently positive sentiment might precede or coincide with upward price trends, and vice-versa.

### Discussion and Insights
(This section would typically include a detailed comparison with a Week 2 price-only model, which was not available for this simulation. However, based on the current model, we can observe...)

The LSTM model, augmented with sentiment features, demonstrates its capability in capturing the temporal dependencies within stock price data. The inclusion of sentiment data aims to provide additional predictive power by accounting for market reactions to news. While a direct comparison to a price-only model from Week 2 was not performed in this simulation, the current model provides a foundation for such an analysis. Future work would involve rigorous quantitative comparison using metrics like RMSE or MAE.

Observations from the sentiment vs. price chart suggest that while sentiment can influence short-term fluctuations, the overall market trend is driven by a multitude of factors. Further analysis would involve lagged correlations between sentiment and price to identify leading or lagging relationships.

### (Optional) Extension: Multi-Stock Analysis
(This section would be populated if a multi-stock analysis was performed, comparing model performance and sentiment impact across different stocks or sectors.)

---

## Conclusion
This comprehensive report details the successful implementation of sentiment analysis and stock trend prediction for Week 3 of the assignment. Part 1 demonstrated the classification of review sentiments, while Part 2 showcased an LSTM model capable of predicting stock prices by integrating both historical price data and news sentiment. The generated code and reports provide a solid foundation for further exploration and refinement of these analytical techniques. All required deliverables, including processed datasets, analysis reports, code, and visualizations, have been generated as specified in the assignment.
