import pandas as pd
import numpy as np
import yfinance as yf
from datetime import datetime, timedelta

def generate_data():
    # 1. Download AAPL stock data
    end_date = datetime.now()
    start_date = end_date - timedelta(days=365*2) # 2 years of data
    
    print(f"Downloading AAPL data from {start_date.date()} to {end_date.date()}...")
    aapl = yf.download('AAPL', start=start_date, end=end_date)
    aapl.reset_index(inplace=True)
    
    # Flatten columns if multi-index (sometimes yfinance does this)
    if isinstance(aapl.columns, pd.MultiIndex):
        aapl.columns = [col[0] for col in aapl.columns]
    
    # 2. Create synthetic news headlines
    # In a real scenario, we'd scrape or use a news API.
    # Here we'll generate headlines that somewhat correlate with price moves.
    
    news_templates = {
        'positive': [
            "Apple reports record-breaking quarterly earnings",
            "New iPhone receives rave reviews from critics",
            "Apple announces major expansion into AI and robotics",
            "Analysts upgrade AAPL stock to 'Strong Buy'",
            "Apple's services revenue hits all-time high",
            "Successful launch of new MacBook models boosts investor confidence",
            "Apple wins major patent lawsuit against competitors",
            "Warren Buffett increases stake in Apple"
        ],
        'negative': [
            "Apple faces supply chain disruptions in key markets",
            "New iPhone sales fall short of analyst expectations",
            "Regulatory scrutiny intensifies for Apple's App Store",
            "Apple's production delayed due to component shortages",
            "Lawsuit filed against Apple over battery performance",
            "Competitors gain market share in the premium smartphone segment",
            "Apple issues rare revenue warning",
            "Major security vulnerability discovered in iOS"
        ],
        'neutral': [
            "Apple to hold its annual developer conference next month",
            "Apple updates its privacy policy for users",
            "Apple CEO Tim Cook speaks at industry summit",
            "Apple explores new office space in Austin",
            "Minor software update released for Apple Watch",
            "Apple's board of directors meets for quarterly review",
            "Apple remains a key player in the tech industry",
            "Market waits for Apple's upcoming product announcement"
        ]
    }
    
    news_data = []
    for i, row in aapl.iterrows():
        date = row['Date']
        price_change = row['Close'] - row['Open']
        
        # Simple logic: if price went up, more likely to have positive news
        if price_change > 0.5:
            sentiment = 'positive'
        elif price_change < -0.5:
            sentiment = 'negative'
        else:
            sentiment = 'neutral'
            
        # Add some randomness
        if np.random.random() > 0.7:
            sentiment = np.random.choice(['positive', 'negative', 'neutral'])
            
        headline = np.random.choice(news_templates[sentiment])
        news_data.append({'Date': date, 'Headline': headline})
        
    news_df = pd.DataFrame(news_data)
    
    # 3. Save datasets
    aapl.to_csv('/home/ubuntu/week3_assignment/data/aapl_stock_prices.csv', index=False)
    news_df.to_csv('/home/ubuntu/week3_assignment/data/aapl_news_headlines.csv', index=False)
    
    print("Datasets generated successfully.")

if __name__ == "__main__":
    generate_data()
