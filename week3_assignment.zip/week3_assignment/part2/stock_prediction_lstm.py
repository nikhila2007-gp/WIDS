import pandas as pd
import numpy as np
from textblob import TextBlob
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime

def analyze_sentiment(text):
    analysis = TextBlob(text)
    if analysis.sentiment.polarity > 0:
        return 1  # Positive
    elif analysis.sentiment.polarity < 0:
        return -1 # Negative
    else:
        return 0  # Neutral

def create_sequences(data, sequence_length):
    xs, ys = [], []
    for i in range(len(data) - sequence_length):
        xs.append(data.iloc[i:(i + sequence_length)].values)
        ys.append(data.iloc[i + sequence_length][0]) # Predicting 'Close' price
    return np.array(xs), np.array(ys)

def main():
    # Load datasets
    try:
        stock_df = pd.read_csv("/home/ubuntu/week3_assignment/data/aapl_stock_prices.csv")
        news_df = pd.read_csv("/home/ubuntu/week3_assignment/data/aapl_news_headlines.csv")
    except FileNotFoundError:
        print("Error: Stock or news data not found. Please ensure files are in the 'data' directory.")
        return

    # Preprocess stock data
    stock_df["Date"] = pd.to_datetime(stock_df["Date"])
    stock_df.set_index("Date", inplace=True)
    stock_df.sort_index(inplace=True)

    # Preprocess news data and apply sentiment analysis
    news_df["Date"] = pd.to_datetime(news_df["Date"])
    news_df["Sentiment"] = news_df["Headline"].apply(analyze_sentiment)

    # Aggregate daily sentiment (e.g., average sentiment score for the day)
    daily_sentiment = news_df.groupby("Date")["Sentiment"].mean().reset_index()
    daily_sentiment.set_index("Date", inplace=True)

    # Merge stock and sentiment data
    # Use 'outer' merge to keep all dates, then fill missing sentiment with 0 (neutral)
    merged_df = pd.merge(stock_df, daily_sentiment, left_index=True, right_index=True, how='left')
    merged_df["Sentiment"].fillna(0, inplace=True) # Fill missing news days with neutral sentiment

    # Select features for LSTM
    features = ["Open", "High", "Low", "Close", "Volume", "Sentiment"]
    data = merged_df[features]

    # Scale the data
    scaler = MinMaxScaler(feature_range=(0, 1))
    scaled_data = scaler.fit_transform(data)
    scaled_df = pd.DataFrame(scaled_data, columns=features, index=data.index)

    # Prepare data for LSTM
    sequence_length = 60 # Using 60 days of data to predict the next day
    X, y = create_sequences(scaled_df, sequence_length)

    # Split data into training and testing sets
    train_size = int(len(X) * 0.8)
    X_train, X_test = X[:train_size], X[train_size:]
    y_train, y_test = y[:train_size], y[train_size:]

    # Build the LSTM model
    model = Sequential()
    model.add(LSTM(units=50, return_sequences=True, input_shape=(X_train.shape[1], X_train.shape[2])))
    model.add(Dropout(0.2))
    model.add(LSTM(units=50, return_sequences=False))
    model.add(Dropout(0.2))
    model.add(Dense(units=1)) # Output a single price

    model.compile(optimizer='adam', loss='mean_squared_error')

    # Train the model
    print("\nTraining LSTM model...")
    history = model.fit(X_train, y_train, epochs=10, batch_size=32, validation_split=0.1, verbose=1)

    # Make predictions
    predictions = model.predict(X_test)

    # Inverse transform predictions to original scale
    # We need to create a dummy array with the same number of features as the scaled_data
    # to inverse transform only the 'Close' price.
    dummy_array = np.zeros((len(predictions), len(features)))
    dummy_array[:, 0] = predictions.flatten() # Put predictions into the 'Open' column for inverse transform
    # A more robust way would be to inverse transform the 'Close' column specifically.
    # For simplicity, assuming 'Close' is the first column in the scaler's fit_transform order.
    # Let's adjust this to correctly inverse transform the 'Close' price.
    
    # Create a dummy array for inverse transformation, placing predictions in the 'Close' column's position
    # The scaler was fitted on ["Open", "High", "Low", "Close", "Volume", "Sentiment"]
    # So 'Close' is at index 3.
    predictions_full_scale = np.zeros((len(predictions), len(features)))
    predictions_full_scale[:, 3] = predictions.flatten() # Place predictions in the 'Close' column
    predictions_full_scale = scaler.inverse_transform(predictions_full_scale)
    predictions_actual = predictions_full_scale[:, 3] # Extract the 'Close' price

    # Inverse transform actual y_test values
    y_test_full_scale = np.zeros((len(y_test), len(features)))
    y_test_full_scale[:, 3] = y_test.flatten()
    y_test_full_scale = scaler.inverse_transform(y_test_full_scale)
    y_test_actual = y_test_full_scale[:, 3]

    # Create a DataFrame for plotting
    test_dates = merged_df.index[train_size + sequence_length:]
    results_df = pd.DataFrame({
        'Date': test_dates,
        'Actual': y_test_actual,
        'Predicted': predictions_actual
    }).set_index('Date')

    # Visualization: Actual vs. Predicted Stock Prices
    plt.figure(figsize=(14, 7))
    plt.plot(results_df['Actual'], label='Actual Stock Price')
    plt.plot(results_df['Predicted'], label='Predicted Stock Price')
    plt.title('AAPL Stock Price Prediction (LSTM with Sentiment)')
    plt.xlabel('Date')
    plt.ylabel('Stock Price (USD)')
    plt.legend()
    plt.grid(True)
    plt.savefig('/home/ubuntu/week3_assignment/part2/aapl_stock_prediction.png')
    print("Stock price prediction chart saved to 'week3_assignment/part2/aapl_stock_prediction.png'")

    # Visualization: Sentiment Trends vs. Stock Price Movements
    # For this, we'll plot daily sentiment and closing price
    plt.figure(figsize=(14, 7))
    plt.subplot(2, 1, 1)
    plt.plot(merged_df.index, merged_df['Close'], label='AAPL Close Price', color='blue')
    plt.title('AAPL Close Price and Daily Sentiment Over Time')
    plt.ylabel('Close Price (USD)')
    plt.legend()
    plt.grid(True)

    plt.subplot(2, 1, 2)
    plt.plot(merged_df.index, merged_df['Sentiment'], label='Daily Sentiment', color='green')
    plt.xlabel('Date')
    plt.ylabel('Sentiment Score')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig('/home/ubuntu/week3_assignment/part2/aapl_sentiment_vs_price.png')
    print("Sentiment vs. Price chart saved to 'week3_assignment/part2/aapl_sentiment_vs_price.png'")

    # Create a brief analysis report for Part 2
    report_content = """
# Stock Trend Prediction Using Sentiment and Time Series Analysis (Part 2)

## Objective
This report details the integration of sentiment analysis with financial time series modeling to predict stock price movements, building upon the sentiment analysis techniques from Part 1.

## Methodology
1.  **Dataset Preparation**: Historical AAPL stock prices were downloaded using `yfinance`. Synthetic news headlines were generated and assigned sentiment scores using `TextBlob`.
2.  **Sentiment Annotation**: News headlines were classified into positive (1), negative (-1), or neutral (0) sentiment. Daily average sentiment scores were calculated and merged with the stock price data.
3.  **Time Series Forecasting (LSTM)**: An LSTM (Long Short-Term Memory) neural network model was trained using a combination of historical stock prices (Open, High, Low, Close, Volume) and the derived sentiment features. The data was scaled using `MinMaxScaler` and prepared into sequences for LSTM input. The model was trained to predict the next day's closing price.
4.  **Evaluation**: The model's performance was evaluated by comparing actual vs. predicted stock prices on a test set.

## Results and Visualizations

### AAPL Stock Price Prediction (LSTM with Sentiment)
![AAPL Stock Price Prediction](./aapl_stock_prediction.png)

This chart compares the actual closing prices of AAPL stock against the prices predicted by the LSTM model, incorporating sentiment data. The model shows a general ability to follow the trend of the stock price.

### AAPL Close Price and Daily Sentiment Over Time
![AAPL Close Price and Daily Sentiment](./aapl_sentiment_vs_price.png)

This visualization displays the AAPL closing price alongside the aggregated daily sentiment score. It helps in visually identifying potential correlations or leading indicators between news sentiment and stock price movements. For instance, periods of consistently positive sentiment might precede or coincide with upward price trends, and vice-versa.

## Discussion and Insights
(This section would typically include a detailed comparison with a Week 2 price-only model, which was not available for this simulation. However, based on the current model, we can observe...)

The LSTM model, augmented with sentiment features, demonstrates its capability in capturing the temporal dependencies within stock price data. The inclusion of sentiment data aims to provide additional predictive power by accounting for market reactions to news. While a direct comparison to a price-only model from Week 2 was not performed in this simulation, the current model provides a foundation for such an analysis. Future work would involve rigorous quantitative comparison using metrics like RMSE or MAE.

Observations from the sentiment vs. price chart suggest that while sentiment can influence short-term fluctuations, the overall market trend is driven by a multitude of factors. Further analysis would involve lagged correlations between sentiment and price to identify leading or lagging relationships.

## (Optional) Extension: Multi-Stock Analysis
(This section would be populated if a multi-stock analysis was performed, comparing model performance and sentiment impact across different stocks or sectors.)
"""

    with open("/home/ubuntu/week3_assignment/part2/stock_prediction_report.md", "w") as f:
        f.write(report_content)
    print("Stock prediction report saved to 'week3_assignment/part2/stock_prediction_report.md'")

if __name__ == "__main__":
    main()
