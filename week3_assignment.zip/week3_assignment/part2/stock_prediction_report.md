
# Stock Trend Prediction Using Sentiment and Time Series Analysis (Part 2)

## Objective
This report details the integration of sentiment analysis with financial time series modeling to predict stock price movements, building upon the sentiment analysis techniques from Part 1.

## Methodology
1.  **Dataset Preparation**: Historical AAPL stock prices were downloaded using `yfinance`. Synthetic news headlines were generated and assigned sentiment scores using `TextBlob`.
2.  **Sentiment Annotation**: News headlines were classified into positive (1), negative (-1), or neutral (0) sentiment. Daily average sentiment scores were calculated and merged with the stock price data.
3.  **Time Series Forecasting (LSTM)**: An LSTM (Long Short-Term Memory) neural network model was trained using a combination of historical stock prices (Open, High, Low, Close, Volume) and the derived sentiment features. The data was scaled using `MinMaxScaler` and prepared into sequences for LSTM input. The model was trained to predict the next day's closing price.
4.  **Evaluation**: The model's performance was evaluated by comparing actual vs. predicted stock prices on a test set.

## Results and Visualizations

### AAPL Stock Price Prediction (LSTM with Sentiment)
![AAPL Stock Price Prediction](./aapl_stock_prediction.png)

This chart compares the actual closing prices of AAPL stock against the prices predicted by the LSTM model, incorporating sentiment data. The model shows a general ability to follow the trend of the stock price.

### AAPL Close Price and Daily Sentiment Over Time
![AAPL Close Price and Daily Sentiment](./aapl_sentiment_vs_price.png)

This visualization displays the AAPL closing price alongside the aggregated daily sentiment score. It helps in visually identifying potential correlations or leading indicators between news sentiment and stock price movements. For instance, periods of consistently positive sentiment might precede or coincide with upward price trends, and vice-versa.

## Discussion and Insights
(This section would typically include a detailed comparison with a Week 2 price-only model, which was not available for this simulation. However, based on the current model, we can observe...)

The LSTM model, augmented with sentiment features, demonstrates its capability in capturing the temporal dependencies within stock price data. The inclusion of sentiment data aims to provide additional predictive power by accounting for market reactions to news. While a direct comparison to a price-only model from Week 2 was not performed in this simulation, the current model provides a foundation for such an analysis. Future work would involve rigorous quantitative comparison using metrics like RMSE or MAE.

Observations from the sentiment vs. price chart suggest that while sentiment can influence short-term fluctuations, the overall market trend is driven by a multitude of factors. Further analysis would involve lagged correlations between sentiment and price to identify leading or lagging relationships.

## (Optional) Extension: Multi-Stock Analysis
(This section would be populated if a multi-stock analysis was performed, comparing model performance and sentiment impact across different stocks or sectors.)
