import pandas as pd
from textblob import TextBlob
import matplotlib.pyplot as plt
import seaborn as sns

def analyze_sentiment(review_text):
    analysis = TextBlob(review_text)
    if analysis.sentiment.polarity > 0:
        return 'positive'
    elif analysis.sentiment.polarity < 0:
        return 'negative'
    else:
        return 'neutral'

def main():
    # Load the dataset
    try:
        df = pd.read_csv('/home/ubuntu/week3_assignment/data/reviews.csv')
    except FileNotFoundError:
        print("Error: reviews.csv not found. Please ensure the file is in the 'data' directory.")
        return

    # Perform sentiment analysis
    df['Sentiment'] = df['ReviewText'].apply(analyze_sentiment)

    # Save the updated dataset
    df.to_csv('/home/ubuntu/week3_assignment/part1/reviews_with_sentiment.csv', index=False)
    print("Updated dataset with sentiment saved to 'week3_assignment/part1/reviews_with_sentiment.csv'")

    # Analyze sentiment distribution
    sentiment_counts = df['Sentiment'].value_counts()
    sentiment_percentages = df['Sentiment'].value_counts(normalize=True) * 100

    print("\nSentiment Distribution:")
    print(sentiment_counts)
    print("\nSentiment Percentages:")
    print(sentiment_percentages)

    # Create a brief analysis report
    report_content = """
# Sentiment Analysis Report (Part 1)

## Objective
This report summarizes the sentiment analysis performed on a dataset of text reviews using TextBlob. The goal was to classify the sentiment of each review into positive, neutral, or negative categories and understand the overall sentiment distribution.

## Methodology
The `TextBlob` library was used to calculate the polarity of each review text. Based on the polarity score:
- Polarity > 0: Classified as 'positive'
- Polarity < 0: Classified as 'negative'
- Polarity = 0: Classified as 'neutral'

## Results
The sentiment analysis resulted in the following distribution:

| Sentiment Category | Number of Reviews | Percentage (%) |
| :----------------- | :---------------- | :------------- |
| Positive           | {pos_count}       | {pos_percent:.2f}      |
| Negative           | {neg_count}       | {neg_percent:.2f}      |
| Neutral            | {neu_count}       | {neu_percent:.2f}      |

## Visualizations

### Sentiment Distribution Bar Chart
![Sentiment Distribution Bar Chart](./sentiment_distribution.png)

## Conclusion
The analysis provides insights into the general sentiment expressed in the reviews. The majority of reviews were classified as {most_common_sentiment}, indicating a generally {overall_sentiment_tone} perception of the product/service reviewed.
""".format(
        pos_count=sentiment_counts.get('positive', 0),
        neg_count=sentiment_counts.get('negative', 0),
        neu_count=sentiment_counts.get('neutral', 0),
        pos_percent=sentiment_percentages.get('positive', 0),
        neg_percent=sentiment_percentages.get('negative', 0),
        neu_percent=sentiment_percentages.get('neutral', 0),
        most_common_sentiment=sentiment_counts.idxmax(),
        overall_sentiment_tone='positive' if sentiment_counts.idxmax() == 'positive' else ('negative' if sentiment_counts.idxmax() == 'negative' else 'neutral')
    )

    with open('/home/ubuntu/week3_assignment/part1/sentiment_analysis_report.md', 'w') as f:
        f.write(report_content)
    print("Sentiment analysis report saved to 'week3_assignment/part1/sentiment_analysis_report.md'")

    # Generate and save visualization
    plt.figure(figsize=(8, 6))
    sns.barplot(x=sentiment_counts.index, y=sentiment_counts.values, palette='viridis')
    plt.title('Sentiment Distribution of Reviews')
    plt.xlabel('Sentiment')
    plt.ylabel('Number of Reviews')
    plt.savefig('/home/ubuntu/week3_assignment/part1/sentiment_distribution.png')
    print("Sentiment distribution chart saved to 'week3_assignment/part1/sentiment_distribution.png'")

if __name__ == "__main__":
    main()
