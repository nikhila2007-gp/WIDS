
# Sentiment Analysis Report (Part 1)

## Objective
This report summarizes the sentiment analysis performed on a dataset of text reviews using TextBlob. The goal was to classify the sentiment of each review into positive, neutral, or negative categories and understand the overall sentiment distribution.

## Methodology
The `TextBlob` library was used to calculate the polarity of each review text. Based on the polarity score:
- Polarity > 0: Classified as 'positive'
- Polarity < 0: Classified as 'negative'
- Polarity = 0: Classified as 'neutral'

## Results
The sentiment analysis resulted in the following distribution:

| Sentiment Category | Number of Reviews | Percentage (%) |
| :----------------- | :---------------- | :------------- |
| Positive           | 11       | 55.00      |
| Negative           | 8       | 40.00      |
| Neutral            | 1       | 5.00      |

## Visualizations

### Sentiment Distribution Bar Chart
![Sentiment Distribution Bar Chart](./sentiment_distribution.png)

## Conclusion
The analysis provides insights into the general sentiment expressed in the reviews. The majority of reviews were classified as positive, indicating a generally positive perception of the product/service reviewed.
